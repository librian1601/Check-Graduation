import { useState, FormEvent } from "react";
import educationLogo from '../assets/education.png'; // Gambar education (dari src/assets)
import loadingLogo from '/loading-logo.png'; // Gambar loading (dari public)

type Siswa = {
  nis: string;
  nama: string;
  ket: "LULUS" | "TIDAK LULUS";
  kompetensi: string;
};

export default function FormKelulusan() {
  const [nis, setNis] = useState<string>("");
  const [hasil, setHasil] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [modalData, setModalData] = useState<Siswa | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setHasil(null);

    try {
      const response = await fetch("/src/assets/data-siswa.json");
      const data: Siswa[] = await response.json();
      const siswa = data.find((item) => item.nis === nis);

      if (siswa) {
        setModalData(siswa);
        setIsModalOpen(true);
      } else {
        setHasil("<p class='text-red-500'>Data Siswa Tidak Ditemukan.</p>");
      }
    } catch (err) {
      setHasil("<p class='text-red-500'>Terjadi kesalahan saat menghubungi server.</p>");
    } finally {
      setLoading(false);
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setModalData(null);
  };

  return (
    <div className="flex flex-col items-center justify-center">
      {/* Gambar Logo Loading */}
      <img
        src={loadingLogo}
        alt="Loading"
        className="mb-6 w-40 h-auto"
      />

      {/* Form Box */}
      <div className="bg-white shadow-lg rounded-lg p-6 w-full max-w-md">
        <h2 className="text-xl font-bold text-gray-800 mb-4 text-center">Cek Kelulusan</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Nomer Induk Siswa"
            value={nis}
            onChange={(e) => setNis(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded mb-4 focus:outline-none focus:ring-2 focus:ring-purple-500"
            required
          />
          <button
            type="submit"
            className="w-full bg-purple-600 text-white p-3 rounded hover:bg-purple-700"
          >
            {loading ? "Memeriksa..." : "Cek Sekarang"}
          </button>
        </form>

        {hasil && (
          <div
            className="mt-4 p-4 border border-gray-200 bg-gray-50 rounded text-sm"
            dangerouslySetInnerHTML={{ __html: hasil }}
          />
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg w-full max-w-md mx-4 sm:max-w-lg">
            <div className="relative bg-gradient-to-br from-purple-500 to-orange-400 p-6 rounded-t-lg flex justify-center items-center">
              <button
                type="button"
                className="absolute top-2 right-2 text-white text-2xl"
                onClick={closeModal}
                aria-label="Close"
              >
                &times;
              </button>
              <div className="absolute top-1/2 transform -translate-y-1/2">
                <img src={educationLogo} alt="Education" className="w-24 h-24 object-contain" />
              </div>
            </div>

            <div className="bg-gradient-to-br from-neutral-300 modal-body text-center p-6 pt-10">
              {modalData && (
                <>
                  <h2 className="text-2xl font-semibold text-black mb-2">{modalData.nama}</h2>
                  {modalData.ket === "LULUS" ? (
                    <span className="bg-green-500 text-white py-2 px-6 rounded-full inline-block">
                      {modalData.ket}
                    </span>
                  ) : (
                    <span className="bg-red-500 text-white py-2 px-6 rounded-full inline-block">
                      {modalData.ket}
                    </span>
                  )}
                  <p className="text-lg mt-4">{modalData.kompetensi}</p>
                  <p className="text-gray-500 mt-2">{modalData.nis}</p>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
