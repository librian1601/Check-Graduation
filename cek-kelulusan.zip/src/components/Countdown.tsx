import { useEffect, useState } from "react";

type CountdownProps = {
  targetDate: Date;
  onFinish: () => void;
};

export default function Countdown({ targetDate, onFinish }: CountdownProps) {
  const [timeLeft, setTimeLeft] = useState<number>(targetDate.getTime() - new Date().getTime());

  useEffect(() => {
    const timer = setInterval(() => {
      const remaining = targetDate.getTime() - new Date().getTime();
      if (remaining <= 0) {
        clearInterval(timer);
        onFinish();
      } else {
        setTimeLeft(remaining);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [targetDate, onFinish]);

  const d = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
  const h = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const m = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
  const s = Math.floor((timeLeft % (1000 * 60)) / 1000);

  return (
    <div className="bg-white shadow-xl rounded-lg p-8 text-center max-w-md w-full">
      <h1 className="text-2xl font-bold text-purple-700 mb-4">Pengumuman Kelulusan</h1>
      <p className="text-lg text-gray-800">
        Dibuka dalam: <br />
        <span className="text-2xl font-mono mt-2 block">{`${d}h ${h}j ${m}m ${s}d`}</span>
      </p>
    </div>
  );
}