import { useState, useEffect } from "react";
import Countdown from "./components/Countdown";
import FormKelulusan from "./components/FormKelulusan";

function App() {
  const targetDate = new Date("2025-05-04T12:00:00");

  const [isTimeUp, setIsTimeUp] = useState(() => new Date() >= targetDate);

  // Update waktu jika user refresh setelah waktu habis
  useEffect(() => {
    if (new Date() >= targetDate) {
      setIsTimeUp(true);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-400 to-violet-600 flex items-center justify-center p-4">
      {!isTimeUp ? (
        <Countdown targetDate={targetDate} onFinish={() => setIsTimeUp(true)} />
      ) : (
        <FormKelulusan />
      )}
    </div>
  );
}

export default App;
